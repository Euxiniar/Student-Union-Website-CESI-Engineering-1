create procedure spl_user_by_email(IN Email_To_Find varchar(255))
BEGIN
	SELECT *
    FROM users
    WHERE Email = Email_To_Find;
END;


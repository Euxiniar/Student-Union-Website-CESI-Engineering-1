create procedure spt_email(IN mailToFind varchar(64))
BEGIN
	SELECT count(*)
    FROM users
    WHERE users.mail = mailToFind;
END;


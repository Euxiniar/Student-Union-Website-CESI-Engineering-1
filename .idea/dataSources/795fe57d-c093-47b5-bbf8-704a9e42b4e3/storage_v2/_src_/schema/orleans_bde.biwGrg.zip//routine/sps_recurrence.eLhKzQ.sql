create procedure sps_recurrence(IN id int)
BEGIN
	SELECT Designation
    FROM recurrences
    WHERE Id_recurrence = id;
END;


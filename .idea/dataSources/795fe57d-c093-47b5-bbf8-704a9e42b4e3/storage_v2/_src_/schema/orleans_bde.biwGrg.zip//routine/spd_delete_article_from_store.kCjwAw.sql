create procedure spd_delete_article_from_store(IN IDArticleInput int)
BEGIN
	DELETE art
    FROM article art
	WHERE art.Id_article = IDArticleInput;
END;


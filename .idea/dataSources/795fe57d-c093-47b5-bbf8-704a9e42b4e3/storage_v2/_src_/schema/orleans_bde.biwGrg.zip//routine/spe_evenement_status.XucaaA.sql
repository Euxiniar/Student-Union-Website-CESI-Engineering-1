create procedure spe_evenement_status(IN id int)
BEGIN
UPDATE evenement
SET Id_status_accessibilite = CASE WHEN Id_status_accessibilite=4 THEN 1 ELSE 4 END
WHERE Id_evenement = id;
END;


create procedure sps_status(IN id int)
BEGIN
	SELECT Designation
    FROM status
    WHERE Id_status=id;
END;


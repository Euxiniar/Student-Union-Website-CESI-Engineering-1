create procedure spe_evenement(IN id int, IN Titre varchar(50), IN Date_evenement date, IN Date_de_creation date,
                               IN Date_de_fin date, IN Description text, IN Cout float, IN Nbr_participants int,
                               IN URL_photo varchar(255), IN Nbr_votes int, IN Lieu varchar(50), IN Id_utilisateur int,
                               IN Id_reccurrence int, IN Is_idea tinyint(1), IN Id_status_accessibilite int)
BEGIN
update `orleans_bde`.`evenement`
SET
	`Titre` = Titre,
	`Date_evenement` = Date_evenement,
	`Date_de_creation` = Date_de_creation,
	`Date_de_fin`= Date_de_fin,
	`Description`= Description,
	`Cout`= Cout,
	`Nbr_participants`= Nbr_participants,
	`URL_photo`= URL_photo,
	`Nbr_votes`= Nbr_votes,
	`Lieu`= Lieu,
	`Id_utilisateur`= Id_utilisateur,
	`Id_reccurrence`= Id_reccurrence,
	`Is_idea`= Is_idea,
	`Id_status_accessibilite`= Id_status_accessibilite
WHERE Id_evenement = id;
END;


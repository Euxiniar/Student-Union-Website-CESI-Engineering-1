create procedure sps_article()
BEGIN
	SELECT *
	FROM article;
END;


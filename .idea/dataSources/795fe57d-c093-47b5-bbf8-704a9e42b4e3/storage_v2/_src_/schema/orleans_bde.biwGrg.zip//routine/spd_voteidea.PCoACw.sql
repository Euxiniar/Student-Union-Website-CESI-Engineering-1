create procedure spd_voteidea(IN id_user int, IN id_event int)
BEGIN
	DELETE FROM voteidea
	WHERE Id_utilisateur = id_user AND
    Id_evenement = id_event;
END;


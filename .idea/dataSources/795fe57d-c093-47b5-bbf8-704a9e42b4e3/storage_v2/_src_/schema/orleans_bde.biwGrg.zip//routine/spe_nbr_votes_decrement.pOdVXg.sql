create procedure spe_nbr_votes_decrement(IN id int)
BEGIN
UPDATE evenement
SET Nbr_votes = Nbr_votes - 1
WHERE Id_evenement = id;
END;


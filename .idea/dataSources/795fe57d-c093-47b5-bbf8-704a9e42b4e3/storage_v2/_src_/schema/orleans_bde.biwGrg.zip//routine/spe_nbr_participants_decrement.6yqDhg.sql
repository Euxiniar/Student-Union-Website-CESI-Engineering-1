create procedure spe_nbr_participants_decrement(IN id int)
BEGIN
UPDATE evenement
SET Nbr_participants = Nbr_participants - 1
WHERE Id_evenement = id;
END;


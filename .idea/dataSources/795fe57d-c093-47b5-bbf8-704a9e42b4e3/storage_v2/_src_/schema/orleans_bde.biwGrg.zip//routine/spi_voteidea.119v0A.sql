create procedure spi_voteidea(IN id_user int, IN id_event int)
BEGIN
INSERT INTO voteidea
VALUES (id_event, id_user);
END;


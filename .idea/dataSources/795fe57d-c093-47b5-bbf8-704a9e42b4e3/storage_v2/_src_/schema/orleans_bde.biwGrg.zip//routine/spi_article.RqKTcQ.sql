create procedure spi_article(IN Titre varchar(50), IN Description text, IN Cout float, IN Image varchar(255),
                             IN stock int, IN Nbr_achats int, IN Id_categorie int)
BEGIN
INSERT INTO `orleans_bde`.`article`
	(
	`Titre`,
	`Description`,
	`Cout`,
	`Image`,
	`stock`,
	`Nbr_achats`,
	`Id_categorie`)
VALUES
(	  
	Titre  ,
	Description  ,
	Cout  ,
	Image  ,
    stock ,
	Nbr_achats ,
	Id_categorie
    );
END;


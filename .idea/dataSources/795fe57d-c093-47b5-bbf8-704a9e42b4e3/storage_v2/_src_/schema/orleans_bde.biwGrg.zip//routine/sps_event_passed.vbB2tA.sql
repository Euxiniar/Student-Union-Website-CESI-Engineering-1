create procedure sps_event_passed(IN id_event int)
BEGIN
SELECT *
    FROM evenement
    WHERE id_status_date = 2
    AND Id_evenement = id_event
    LIMIT 20;
END;


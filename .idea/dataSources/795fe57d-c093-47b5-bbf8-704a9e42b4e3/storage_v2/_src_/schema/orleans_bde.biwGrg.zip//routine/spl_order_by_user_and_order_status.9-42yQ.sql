create procedure spl_order_by_user_and_order_status(IN idUser int)
BEGIN
SELECT article.Titre, article.Description, article.Cout, article.Image, article_par_commande.Quantite, article_par_commande.Id_article, article_par_commande.Id_commande, commande.Cout_total, article.Stock
    FROM article, commande, article_par_commande
    WHERE idUser = commande.Id_utilisateur AND article_par_commande.Id_article = article.Id_article AND Commande_payee = 0;
END;


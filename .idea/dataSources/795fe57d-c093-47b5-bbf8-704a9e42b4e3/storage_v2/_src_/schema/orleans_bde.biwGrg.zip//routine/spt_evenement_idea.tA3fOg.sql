create procedure spt_evenement_idea()
BEGIN
	SELECT count
    FROM evenement
    WHERE Is_idea = 1;
END;


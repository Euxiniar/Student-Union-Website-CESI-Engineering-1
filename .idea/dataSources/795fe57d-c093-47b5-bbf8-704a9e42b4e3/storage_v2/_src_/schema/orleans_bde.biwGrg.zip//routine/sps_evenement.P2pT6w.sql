create procedure sps_evenement(IN id int)
BEGIN
	SELECT *
    FROM evenement
    WHERE Id_evenement = id;
END;


create procedure spl_participant_evenement()
BEGIN
select *
from participant_evenement;
END;


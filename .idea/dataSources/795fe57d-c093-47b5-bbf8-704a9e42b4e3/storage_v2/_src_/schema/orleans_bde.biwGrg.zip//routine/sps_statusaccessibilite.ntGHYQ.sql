create procedure sps_statusaccessibilite(IN id int)
BEGIN
	SELECT Designation
    FROM statusaccessibilite
    WHERE Id_status_accessibilite=id;
END;


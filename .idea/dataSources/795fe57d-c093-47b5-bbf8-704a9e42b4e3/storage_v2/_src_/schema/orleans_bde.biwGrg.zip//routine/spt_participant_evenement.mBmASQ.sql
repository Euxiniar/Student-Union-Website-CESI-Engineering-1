create procedure spt_participant_evenement(IN id_user int, IN id_event int)
BEGIN
SELECT COUNT(Id_utilisateur) AS count
FROM participant_evenement
WHERE id_user = Id_utilisateur AND
id_event = Id_evenement;
END;


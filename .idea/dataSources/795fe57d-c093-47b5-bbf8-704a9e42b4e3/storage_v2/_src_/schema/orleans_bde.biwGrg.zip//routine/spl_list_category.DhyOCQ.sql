create procedure spl_list_category()
BEGIN
	SELECT *
    FROM catégorie;
END;


create procedure spd_delete_item_from_cart_by_id_user_and_article(IN IDUserInput int, IN IDArticleInput int)
BEGIN
	DELETE apc
    FROM article_par_commande apc
    JOIN commande com ON com.Id_commande = apc.Id_commande
	WHERE IDArticleInput = apc.Id_article AND com.Commande_payee = 0 AND IDUserInput = com.Id_utilisateur;
END;


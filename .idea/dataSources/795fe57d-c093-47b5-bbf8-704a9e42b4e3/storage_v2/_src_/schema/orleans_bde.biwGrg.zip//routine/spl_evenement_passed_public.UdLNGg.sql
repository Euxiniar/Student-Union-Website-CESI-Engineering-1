create procedure spl_evenement_passed_public()
BEGIN
	SELECT *
    FROM evenement
    WHERE id_status_date = 2 AND Id_status_accessibilite=1
    LIMIT 20;
END;


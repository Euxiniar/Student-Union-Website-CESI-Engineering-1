create procedure sps_user_by_email(IN mail varchar(255))
BEGIN
	SELECT *
    FROM utilisateur
    WHERE Email=mail;
END;


create procedure sps_event(IN id_event int)
BEGIN
SELECT *
    FROM evenement
WHERE Id_evenement = id_event
    LIMIT 20;
END;


create procedure sps_participant_evenement(IN id int)
BEGIN
select * 
from participant_evenement
where Id_evenement = id;
END;


create procedure sps_genre(IN id int)
BEGIN
	SELECT Designation
    FROM genre
    WHERE Id_genre = id;
END;


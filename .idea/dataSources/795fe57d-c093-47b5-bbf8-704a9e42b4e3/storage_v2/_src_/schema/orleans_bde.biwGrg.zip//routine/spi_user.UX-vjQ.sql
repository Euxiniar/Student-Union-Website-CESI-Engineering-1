create procedure spi_user(IN F_Name varchar(40), IN L_Name varchar(40), IN Email varchar(255), IN mdp varchar(255),
                          IN ID_Campus int, IN ID_Gender int, IN ID_Role int)
BEGIN
  INSERT INTO `orleans_bde`.utilisateur
  (Prenom,
   Nom,
   Email,
   mdp,
   Id_centre,
   Id_genre,
   Id_Status)
  VALUES
  (F_Name, L_Name , Email , Mdp,
   ID_Campus , ID_Gender , ID_Role);
END;


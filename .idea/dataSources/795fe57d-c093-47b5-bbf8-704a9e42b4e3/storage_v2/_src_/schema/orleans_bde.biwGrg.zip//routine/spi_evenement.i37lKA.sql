create procedure spi_evenement(IN Titre varchar(50), IN Date_evenement date, IN Date_de_creation date,
                               IN Date_de_fin date, IN Description text, IN Cout float, IN Nbr_participants int,
                               IN URL_photo varchar(255), IN Nbr_votes int, IN Lieu varchar(50), IN Id_utilisateur int,
                               IN Id_reccurrence int, IN Is_idea tinyint(1), IN Id_status_accessibilite int)
BEGIN
INSERT INTO `orleans_bde`.`evenement`
	(
	`Titre`,
	`Date_evenement`,
	`Date_de_creation`,
	`Date_de_fin`,
	`Description`,
	`Cout`,
	`Nbr_participants`,
	`URL_photo`,
	`Nbr_votes`,
	`Lieu`,
	`Id_utilisateur`,
	`Id_reccurrence`,
	`Is_idea`,
	`Id_status_accessibilite`)
VALUES
(	  
	Titre  ,
	Date_evenement  ,
	Date_de_creation  ,
	Date_de_fin  ,
	Description  ,
	Cout  ,
	Nbr_participants  ,
	URL_photo  ,
	Nbr_votes  ,
	Lieu  ,
	Id_utilisateur  ,
	Id_reccurrence  ,
	Is_idea  ,
	Id_status_accessibilite  
    );
END;


create procedure spe_evenement_idea_to_tocome(IN id int)
BEGIN
update evenement
set Is_idea = 0,
	Id_status_date = 1
WHERE Id_evenement=id;
END;


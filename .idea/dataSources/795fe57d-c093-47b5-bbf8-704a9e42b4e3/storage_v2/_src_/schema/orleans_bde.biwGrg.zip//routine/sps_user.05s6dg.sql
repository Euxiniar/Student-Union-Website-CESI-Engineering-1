create procedure sps_user(IN id int)
BEGIN
	SELECT *
    FROM utilisateur
    WHERE Id_Utilisateur = id;
END;


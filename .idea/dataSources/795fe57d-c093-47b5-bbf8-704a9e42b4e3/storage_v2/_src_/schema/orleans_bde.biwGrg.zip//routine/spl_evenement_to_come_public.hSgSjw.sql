create procedure spl_evenement_to_come_public()
BEGIN
	SELECT *
    FROM evenement
    WHERE id_status_date = 1 AND Id_status_accessibilite=1
    LIMIT 20;
END;


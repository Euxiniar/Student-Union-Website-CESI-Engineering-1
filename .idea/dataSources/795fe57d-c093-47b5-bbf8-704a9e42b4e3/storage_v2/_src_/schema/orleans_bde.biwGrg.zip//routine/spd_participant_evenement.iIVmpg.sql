create procedure spd_participant_evenement(IN id_user int, IN id_event int)
BEGIN
	DELETE FROM participant_evenement
	WHERE Id_utilisateur = id_user AND
    Id_evenement = id_event;
END;


create procedure spl_evenements_idea()
BEGIN
	SELECT *
    FROM evenement
    WHERE Is_idea = 1
    ORDER BY Nbr_votes DESC;
END;


create procedure spt_utilisateur_has_vote(IN id_user int, IN id_event int)
BEGIN
SELECT COUNT(Id_utilisateur) AS count
FROM voteidea
WHERE Id_utilisateur = id_user AND
Id_evenement = id_event ;
END;


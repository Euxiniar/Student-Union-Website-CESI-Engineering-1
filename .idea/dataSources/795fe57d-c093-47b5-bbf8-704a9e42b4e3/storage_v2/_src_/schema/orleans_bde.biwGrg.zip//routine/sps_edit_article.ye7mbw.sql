create procedure sps_edit_article(IN id int)
BEGIN
	SELECT *
    FROM evenement
    WHERE Id_evenement = id;
END;


create procedure spl_evenement_to_come()
BEGIN
	SELECT *
    FROM evenement
    WHERE id_status_date = 1
    LIMIT 20;
END;


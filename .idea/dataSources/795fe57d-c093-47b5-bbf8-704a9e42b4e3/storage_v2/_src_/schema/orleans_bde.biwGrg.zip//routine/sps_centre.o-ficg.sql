create procedure sps_centre(IN id int)
BEGIN
	SELECT Designation
    FROM centre
    WHERE idCentre=id;
END;


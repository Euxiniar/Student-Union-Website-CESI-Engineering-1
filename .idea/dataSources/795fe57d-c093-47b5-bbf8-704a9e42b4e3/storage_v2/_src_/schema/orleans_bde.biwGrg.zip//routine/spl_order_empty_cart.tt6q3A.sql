create procedure spl_order_empty_cart(IN idUser int, IN idCommande int)
BEGIN
	DELETE apc FROM article_par_commande apc JOIN commande com ON com.Id_Commande = idCommande WHERE com.Id_Utilisateur = idUser AND apc.Id_commande = com.Id_commande AND Commande_payee = 0;
    DELETE com FROM commande com WHERE com.Id_Utilisateur = idUser AND com.Id_commande = idCommande AND Commande_payee = 0;
END;


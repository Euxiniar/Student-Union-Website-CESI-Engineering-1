create procedure spe_update_item_quantity_in_cart(IN UserID int, IN Quantity int, IN ArticleID int)
BEGIN
	UPDATE article_par_commande apc
	JOIN commande com ON com.Id_commande = apc.Id_commande
	SET apc.Quantite = Quantity
	WHERE apc.Id_article = ArticleID AND com.Id_utilisateur = UserID AND Commande_payee = 0;
END;


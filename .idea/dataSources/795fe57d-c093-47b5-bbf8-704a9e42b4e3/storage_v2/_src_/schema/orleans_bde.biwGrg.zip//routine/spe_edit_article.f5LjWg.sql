create procedure spe_edit_article(IN id int, IN Titre varchar(50), IN Description text, IN Cout float,
                                  IN Image varchar(255), IN stock int, IN Nbr_achats int, IN Id_categorie int)
BEGIN
update `orleans_bde`.`article`
SET

	`Titre`= Titre,
	`Description`= Description,
	`Cout`= Cout,
	`Image`= Image,
	`stock` = stock,
	`Nbr_achats`= Nbr_achats,
	`Id_categorie`= Id_categorie
    WHERE Id_article = id;
END;


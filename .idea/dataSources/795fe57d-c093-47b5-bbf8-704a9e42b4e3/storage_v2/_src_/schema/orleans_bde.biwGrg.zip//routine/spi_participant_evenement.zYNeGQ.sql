create procedure spi_participant_evenement(IN id_user int, IN id_event int)
BEGIN
INSERT INTO participant_evenement
VALUES (id_user, id_event);
END;


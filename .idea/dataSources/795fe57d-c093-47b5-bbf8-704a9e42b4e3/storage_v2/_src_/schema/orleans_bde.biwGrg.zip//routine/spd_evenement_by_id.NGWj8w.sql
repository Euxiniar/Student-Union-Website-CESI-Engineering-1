create procedure spd_evenement_by_id(IN id int)
BEGIN
	DELETE FROM evenement
	WHERE Id_evenement = id;
END;

